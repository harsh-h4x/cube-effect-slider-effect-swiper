# Cube Effect Slider | Swiper JS and tsParticles

A Pen created on CodePen.io. Original URL: [https://codepen.io/ecemgo/pen/ZEPYNXJ](https://codepen.io/ecemgo/pen/ZEPYNXJ).

This pen features a responsive landing page with a cube-effect slider powered by Swiper JS and an animated background created using tsParticles.

Note: Please do not use this on commercial platforms or projects without permission.